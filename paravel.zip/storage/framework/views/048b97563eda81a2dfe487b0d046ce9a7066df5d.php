

<?php $__env->startSection('title'); ?>
    Cupon
<?php $__env->stopSection(); ?>

<?php $__env->startSection('cupon'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<nav class="breadcrumb sl-breadcrumb">
    <a class="breadcrumb-item" href=" <?php echo e(route('home')); ?> ">Dashbroad</a>
    <span class="breadcrumb-item active">Cupon</span>
</nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-lg-6 pt-1">Category List</div>
                        <div class="col-lg-6 text-right">
                            <?php if($cupons->count() != 0): ?>
                                <a href="<?php echo e(route('cart.delete.all')); ?>" class="btn btn-danger">Delete All</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <?php if(session('category_delete_status')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('category_delete_status')); ?>

                            </div>
                        <?php endif; ?>
                        <div class="alert alert-success text-center">
                            Total Category <?php echo e($cupons->count()); ?>

                        </div>
                        <thead>
                            <tr>
                                <th>Serial No</th>
                                <th>Cupon Name</th>
                                <th>Discount Amount</th>
                                <th>Expire Date</th>
                                <th>Uses</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <form action=" <?php echo e(route('category_check_delete')); ?> " method="POST">
                                <?php echo csrf_field(); ?>
                                <?php $__empty_1 = true; $__currentLoopData = $cupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td> <?php echo e($loop->index+1); ?> </td>
                                    <td> <?php echo e(Str::title($cupon->cupon_name)); ?> </td>
                                    <td> <?php echo e($cupon->discount_amount); ?> %</td>
                                    <td> <?php echo e($cupon->expire_date); ?> </td>
                                    <td> <?php echo e($cupon->uses_limit); ?> </td>
                                    <td>
                                        <div class="btn-group" role="group" aria-label="Basic example">
                                            <a href="<?php echo e(route('cupon.edit', $cupon->id)); ?>" type="button" class="btn btn-info text-white">Edit</a>
                                            <form action="<?php echo e(route('cupon.destroy', $cupon->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="btn btn-danger">
                                                    Delete
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="9" class="text-center text-danger">No Data To Show</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header">Add Cupon</div>
                <div class="card-body">
                    <form action=" <?php echo e(route('cupon.store')); ?> " method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label>Cupon Name</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['cupon_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="cupon_name" value="<?php echo e(old('cupon_name')); ?>">
                            <?php $__errorArgs = ['cupon_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger d-block"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <label>discount amount</label>
                            <input type="number" class="form-control <?php $__errorArgs = ['discount_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="discount_amount" value="<?php echo e(old('discount_amount')); ?>">
                            <?php $__errorArgs = ['discount_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger d-block"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            <label>expire_date</label>
                            <input type="date" class="form-control <?php $__errorArgs = ['expire_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="expire_date" value="<?php echo e(old('expire_date')); ?>">
                            <?php $__errorArgs = ['expire_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger d-block"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            <label>uses_limit</label>
                            <input type="number" class="form-control <?php $__errorArgs = ['uses_limit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="uses_limit" value="<?php echo e(old('uses_limit')); ?>">
                            <?php $__errorArgs = ['uses_limit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger d-block"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <button type="submit" class="btn btn-outline-secondary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.starlight', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\paravel\resources\views/cupon/index.blade.php ENDPATH**/ ?>