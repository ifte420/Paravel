

<?php $__env->startSection('title'); ?>
    Edit <?php echo e($category_info->category_name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('category'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <nav class="breadcrumb sl-breadcrumb">
        <a class="breadcrumb-item" href=" <?php echo e(route('home')); ?> ">Dashbroad</a>
        <a class="breadcrumb-item" href=" <?php echo e(route('category')); ?> ">Category</a>
        <span class="breadcrumb-item active"><?php echo e($category_info->category_name); ?></span>
    </nav>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-6 m-auto">
                <div class="card">
                    <div class="card-header text-white bg-secondary">Edit Categroy</div>
                    <div class="card-body">
                        <form action=" <?php echo e(route('category_post_edit')); ?> " method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <input type="hidden" value="<?php echo e($category_info->id); ?>" name="category_id">
                                <label for="exampleInputPassword1">Category Name</label>
                                <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Enter Categroy Name" name="category_name" value="<?php echo e($category_info->category_name); ?>">
                                <?php if($errors->all()): ?>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="text-danger"> <?php echo e($error); ?> </span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                            <button type="submit" class="btn btn-outline-secondary">Update Category</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.starlight', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\paravel\resources\views/category/edit.blade.php ENDPATH**/ ?>