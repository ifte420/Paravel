<div class="col-lg-12">
    <div class="card">
        <div class="card-header">Customer Dashbroad</div>
        <div class="card-body">
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Serial Number</th>
                        <th>Name</th>
                        <th>Phone Number</th>
                        <th>subtotal</th>
                        <th>Discount</th>
                        <th>Total</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th> <?php echo e($loop->index+1); ?> </th>
                            <td> <?php echo e(Str::title($order->customer_name)); ?></td>
                            <td><?php echo e($order->customer_phone_number); ?></td>
                            <td><?php echo e($order->subtotal); ?></td>
                            <td><?php echo e($order->discount); ?></td>
                            <td><?php echo e($order->total); ?></td>
                            <td>
                                <a href="<?php echo e(route('download_invoice', $order->id)); ?>"><i class="fa fa-download"></i>Download Invoice</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH F:\paravel\resources\views/customer/dashbroad.blade.php ENDPATH**/ ?>