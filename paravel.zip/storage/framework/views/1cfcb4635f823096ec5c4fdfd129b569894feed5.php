

<?php $__env->startSection('title'); ?>
    Sub Category Page
<?php $__env->stopSection(); ?>
<?php $__env->startSection('subcategory'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <nav class="breadcrumb sl-breadcrumb">
        <a class="breadcrumb-item" href=" <?php echo e(route('home')); ?> ">Dashbroad</a>
        <a class="breadcrumb-item" href=" <?php echo e(route('category')); ?> ">Category</a>
        <span class="breadcrumb-item active">Sub Category</span>
    </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header text-white bg-secondary">
                    <div class="row">
                        <div class="col-lg-6 pt-1">Category List</div>
                        <div class="col-lg-6 text-right">
                            <?php if($subcategorys->count() != 0 ): ?>
                            <a href="<?php echo e(route('allsoftdelete')); ?>" class="btn btn-danger">Delete All</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <div class="alert alert-success text-center">
                            Total Sub Category <?php echo e($subcategorys->count()); ?>

                        </div>
                        <?php if(session('soft_delete')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('soft_delete')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(session('softall')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('softall')); ?>

                            </div>
                        <?php endif; ?>
                        <thead>
                            <tr>
                                <th>Serial No</th>
                                <th>Sub Category Name</th>
                                <th>Sub Category Image</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $subcategorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td> <?php echo e($loop->index+1); ?> </td>
                                <td> <?php echo e(Str::title($subcategory->subcategory_name)); ?> </td>
                                <td>
                                    <div class="image">
                                        <img src="<?php echo e(asset('uploads/sub_category')); ?>/<?php echo e($subcategory->subcategory_image); ?>" alt="Not Found" class="img-fluid">
                                    </div>
                                </td>
                                <td>
                                    <div class="btn-group" role="group" aria-label="Basic example">
                                        <a href=" <?php echo e(route('subcategoryedit',$subcategory->id)); ?>" type="button" class="btn btn-outline-info">Edit</a>
                                        <a href=" <?php echo e(route('subcategorydelete',$subcategory->id)); ?>" type="button" class="btn btn-outline-danger">Delete</a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center text-danger">No Data To Show</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header text-white bg-secondary">Add Sub Categroy</div>
                <div class="card-body">
                    <?php if(session('insert_success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('insert_success')); ?>

                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('subcategory_post')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label>Category Name</label>
                            <select class="form-control" name="category_id">
                                <option>-Choose One-</option>
                                <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Sub Category Name</label>
                            <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Enter Categroy Name" name="subcategory_name">
                            <?php $__errorArgs = ['subcategory_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <label>Sub Category Image</label>
                            <input class="form-control form-control-sm" type="file" name="subcategory_image">
                            <?php $__errorArgs = ['subcategory_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <button type="submit" class="btn btn-outline-secondary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-5">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header bg-warning">
                    <div class="row">
                        <div class="col-lg-6 pt-1 text-white">Total Soft Category List</div>
                        <div class="col-lg-6 text-right">
                            <?php if($subcategorys_trashed->count() != 0 ): ?>
                                <a href="<?php echo e(route('subcategoryallrestore')); ?>" class="btn btn-success">Restore All</a>
                                <a href="<?php echo e(route('subcategoryallforcedelete')); ?>" class="btn btn-danger">Delete All</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?php if(session('single_restore')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('single_restore')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('single_force_delete')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('single_force_delete')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('restore_all')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('restore_all')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('forcedelete')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('forcedelete')); ?>

                        </div>
                    <?php endif; ?>
                    <table class="table table-bordered">
                        <div class="alert alert-success text-center">
                            Category List
                        </div>
                        <thead>
                            <tr>
                                <th>Serial No</th>
                                <th>Sub Category Name</th>
                                <th>Sub Category Image</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $subcategorys_trashed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td> <?php echo e($loop->index+1); ?> </td>
                                <td> <?php echo e(Str::title($subcategory->subcategory_name)); ?> </td>
                                <td>
                                    <div class="image">
                                        <img src="<?php echo e(asset('uploads/sub_category')); ?>/<?php echo e($subcategory->subcategory_image); ?>" alt="Not Found" class="img-fluid">
                                    </div>
                                </td>
                                <td>
                                    <div class="btn-group" role="group" aria-label="Basic example">
                                        <a href=" <?php echo e(route('subcategoryrestore',$subcategory->id)); ?>" type="button" class="btn btn-success">Restore</a>
                                        <a href=" <?php echo e(route('subcategoryfocedelete',$subcategory->id)); ?>" type="button" class="btn btn-danger">Froce Delete</a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center text-danger">No Data To Show</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.starlight', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\paravel\resources\views/subcategory/index.blade.php ENDPATH**/ ?>