<h1>Contact Message</h1>
<p>Person Name: <?php echo e($final_message_contact[0]); ?></p>
<p>Email:<?php echo e($final_message_contact[1]); ?></p>
<p>Subject:<?php echo e($final_message_contact[2]); ?></p>
<p>Message:<?php echo e($final_message_contact[3]); ?></p><?php /**PATH F:\paravel\resources\views/mail/sendcontactmessage.blade.php ENDPATH**/ ?>