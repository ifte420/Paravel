
<?php $__env->startSection('title'); ?>
    <?php echo e($one_category->category_name); ?> Category Wise Product
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
<!-- .breadcumb-area start -->
<div class="breadcumb-area bg-img-4 ptb-100">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcumb-wrap text-center">
                    <h2>Shop Page</h2>
                    <ul>
                        <li><a href="<?php echo e(route('tohoney_home')); ?>">Home</a></li>
                        <li><span><?php echo e($one_category->category_name); ?></span></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- .breadcumb-area end -->
<!-- product-area start -->
<div class="product-area pt-100">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section-title">
                    <h2><?php echo e($one_category->category_name); ?> Category Wise Product</h2>
                    <img src="<?php echo e(asset('tohoney_assets')); ?>/images/section-title.png" alt="">
                </div>
            </div>
        </div>
        <div class="tab-content">
            <div class="tab-pane active" id="all">
                <ul class="row">
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php echo $__env->make('little_part.product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-lg-12 col-sm-12 col-12 text-center" style="background: #EF4836; color:#ffffff; height:50px;">
                        <div class="alert">
                            <?php echo e($one_category->category_name); ?> category has no product
                        </div>
                    </div>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- product-area end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.tohoney', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\paravel\resources\views/categorywiseshop.blade.php ENDPATH**/ ?>