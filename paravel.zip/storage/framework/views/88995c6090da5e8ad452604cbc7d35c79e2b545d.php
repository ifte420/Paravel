

<?php $__env->startSection('title'); ?>
    Product Page
<?php $__env->stopSection(); ?>
<?php $__env->startSection('product'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <nav class="breadcrumb sl-breadcrumb">
        <a class="breadcrumb-item" href=" <?php echo e(route('home')); ?> ">Dashbroad</a>
        <a class="breadcrumb-item" href=" <?php echo e(route('category')); ?> ">Category</a>
        <span class="breadcrumb-item active">Product Page</span>
    </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">Add Product</div>
                <div class="card-body">
                    <?php if(session('product_added')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('product_added')); ?>

                        </div>
                    <?php endif; ?>
                    <form action=" <?php echo e(route('productpost')); ?> " method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label>Category Name</label>
                            <select class="form-control" name="category_id" id="category_select">
                                <option value="">-Choose One-</option>
                                <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label>Sub Category Name</label>
                            <select class="form-control" name="subcategory_id" id="subcategory_list">
                                <option value="">-Choose One-</option>
                                
                            </select>
                            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label>Product Name</label>
                            <input type="text" class="form-control" placeholder="Enter product Name" name="product_name">
                            <?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label>Product price</label>
                            <input type="number" class="form-control" placeholder="Enter product price" name="product_price">
                            <?php $__errorArgs = ['product_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label>Product quantity</label>
                            <input type="number" class="form-control" placeholder="Product quantity" name="product_quantity">
                            <?php $__errorArgs = ['product_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label>Product short description</label>
                            <input type="text" class="form-control" placeholder="product short_description" name="product_short_description">
                            <?php $__errorArgs = ['product_short_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label>Product long description</label>
                            <input type="text" class="form-control" placeholder="Enter Categroy Name" name="product_long_description">
                            <?php $__errorArgs = ['product_long_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label>Product alert quantity</label>
                            <input type="number" class="form-control" placeholder="Enter alert quantity" name="product_alert_quantity">
                            <?php $__errorArgs = ['product_alert_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label>Product Image</label>
                            <input class="form-control form-control-sm" type="file" placeholder="Enter Product Image" name="product_image">
                            <?php $__errorArgs = ['product_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label>Feature Product Image</label>
                            <input class="form-control form-control-sm" type="file" placeholder="Feature Product Image" name="feature_image[]" multiple>
                            <?php $__errorArgs = ['feature_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <button type="submit" class="btn btn-outline-secondary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-5">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-lg-6 pt-1">Product List</div>
                        <div class="col-lg-6 text-right">
                            <?php if($products->count() != 0 ): ?>
                                <div id="delete_soft_all" class="btn btn-danger">Delete All</div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                    <table class="table table-bordered">
                        <?php if(session('single_soft_delete')): ?>
                            <div class="alert alert-danger text-center">
                                <?php echo e(session('single_soft_delete')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(session('delete_all_soft')): ?>
                            <div class="alert alert-danger text-center">
                                <?php echo e(session('delete_all_soft')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(session('edit_success')): ?>
                            <div class="alert alert-success text-center">
                                <?php echo e(session('edit_success')); ?>

                            </div>
                        <?php endif; ?>
                        <div class="alert alert-success text-center">
                            Total Product <?php echo e($products->count()); ?>

                        </div>
                        <thead>
                            <tr>
                                
                                <th>Serial No</th>
                                <th>Product Name</th>
                                <th>Category Name</th>
                                <th>Added By</th>
                                <th>Product Price</th>
                                <th>Product Quantity</th>
                                <th>Product Alert Quantitiy</th>
                                <th>Product Image</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                            <tbody>
                            
                                
                                
                                
                                
                                        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                
                                                <td> <?php echo e($loop->index+1); ?> </td>
                                                <td> <?php echo e(Str::title($product->product_name)); ?> </td>
                                                <td><?php echo e(App\Models\Category::find($product->category_id)->category_name); ?></td>
                                                <td><?php echo e(App\Models\User::find($product->user_id)->name); ?></td>
                                                <td><?php echo e($product->product_price); ?></td>
                                                <td><?php echo e($product->product_quantity); ?></td>
                                                <td><?php echo e($product->product_alert_quantity); ?></td>
                                                <td><img src="<?php echo e(asset('uploads/product/'. $product->product_image)); ?>" alt="not found" style="height: 200px; width:200px"></td>
                                                <td>
                                                    <div class="btn-group" role="group" aria-label="Basic example">
                                                        <a href="<?php echo e(route('product_edit',$product->id)); ?>" type="button" class="btn btn-info text-white">Edit</a>
                                                        <a href=" <?php echo e(route('productsoftdelete',$product->id)); ?>" type="button" class="btn btn-danger">Delete</a>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="8" class="text-center text-danger">No Data To Show</td>
                                            </tr>
                                        <?php endif; ?>
                                    
                            </tbody>
                        </table>
                        </div>
                        
                        
                        
                    
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-5">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header bg-warning">
                    <div class="row">
                        <div class="col-lg-6 pt-1 text-white">Total Soft Category List</div>
                            <div class="col-lg-6 text-right">
                                <?php if($product_trashed->count() != 0 ): ?>
                                    <button class="btn btn-success" id="restore_all">Restore All</button>
                                    <button class="btn btn-danger" id="delete_force_all">Delete All</button>
                                <?php endif; ?>
                            </div>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <div class="alert alert-success text-center">
                            Category List <?php echo e($product_trashed->count()); ?>

                        </div>
                        <?php if(session('single_restore')): ?>
                            <div class="alert alert-success text-center">
                                <?php echo e(session('single_restore')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(session('all_restore')): ?>
                            <div class="alert alert-success text-center">
                                <?php echo e(session('all_restore')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(session('single_force')): ?>
                            <div class="alert alert-danger text-center">
                                <?php echo e(session('single_force')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(session('all_force_delete')): ?>
                            <div class="alert alert-danger text-center">
                                <?php echo e(session('all_force_delete')); ?>

                            </div>
                        <?php endif; ?>
                        <thead>
                            <tr>
                                <th>Serial No</th>
                                <th>Product Name</th>
                                <th>Category Name</th>
                                <th>Product Price</th>
                                <th>Product Quantity</th>
                                <th>Product Alert Quantitiy</th>
                                <th>Product Image</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $product_trashed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_trash): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    
                                    <td> <?php echo e($loop->index+1); ?> </td>
                                    <td> <?php echo e(Str::title($product_trash->product_name)); ?> </td>
                                    <td><?php echo e(App\Models\Category::withTrashed()->find($product_trash->category_id)->category_name); ?></td>
                                    
                                    <td><?php echo e($product_trash->product_price); ?></td>
                                    <td><?php echo e($product_trash->product_quantity); ?></td>
                                    <td><?php echo e($product_trash->product_alert_quantity); ?></td>
                                    <td><img src="<?php echo e(asset('uploads/product/'. $product_trash->product_image)); ?>" alt="not found" style="height: 200px; width:200px"></td>
                                    <td>
                                        <div class="btn-group" role="group" aria-label="Basic example">
                                            <a href=" <?php echo e(route('product_restore',$product_trash->id)); ?>" type="button" class="btn btn-success text-white">Restore</a>
                                            <a href=" <?php echo e(route('productforce',$product_trash->id)); ?>" type="button" class="btn btn-danger">Delete</a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="8" class="text-center text-danger">No Data To Show</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                    </table>
                            
                        
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->startSection('footer_script'); ?>
    <script>
        $(document).ready(function(){
            $('#delete_soft_all').click(function(){
                Swal.fire({
                    title: 'Are you sure you want to soft delete?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                    }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href ="<?php echo e(route('product_all_soft_delete')); ?>";
                    }
                })
            });

            $('#delete_force_all').click(function(){
                Swal.fire({
                title: 'Are you sure you want to delete by force?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = "<?php echo e(route('product_force_delete_all')); ?>";
                    }
                })
            });

            $('#restore_all').click(function(){
                Swal.fire({
                title: 'Are you sure you want to Restore All?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = "<?php echo e(route('product_restore_all')); ?>";
                    }
                })
            });

            $('#all_check_btn').click(function(){
                $('.delete_checkbox').attr('checked', 'checked');
            });

            $('#all_uncheck_btn').click(function(){
                $('.delete_checkbox').removeAttr('checked');
            });

            $('#all_checked').click(function(){
                $('.checked_button').attr('checked', 'checked');
            });

            $('#all_unchecked').click(function(){
                $('.checked_button').removeAttr('checked');
            });
            // Select 2
            $('#category_select').select2();
            $('#subcategory_list').select2();
            $('#category_select').change(function(){
                var category_id = $(this).val();
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: 'POST',
                    url: 'get/subcategory/list',
                    data: {category_id:category_id},
                    success: function(data){
                        $('#subcategory_list').html(data);
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.starlight', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\paravel\resources\views/product/index.blade.php ENDPATH**/ ?>