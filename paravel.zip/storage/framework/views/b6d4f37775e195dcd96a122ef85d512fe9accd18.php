<?php $__env->startSection('title'); ?>
    Dashbroad Page
<?php $__env->stopSection(); ?>
<?php $__env->startSection('dashboard'); ?>
    active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <nav class="breadcrumb sl-breadcrumb">
        <span class="breadcrumb-item active">Dashbroad</span>
    </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(Auth::user()->role == 1): ?>
        <div class="row justify-content-center mb-5">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header">
                        Payment Chart
                    </div>
                    <div class="card-body">
                        <div>
                            <canvas id="myChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <div class="row justify-content-center">
        <?php if(Auth::user()->role == 1): ?>
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <div class="alert alert-success text-center">
                            Total Users: <?php echo e($users->count()); ?>

                        </div>
                        <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Serial Number</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Created Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th> <?php echo e($loop->index+1); ?> </th>
                                    <td> <?php echo e(Str::title($user->name)); ?></td>
                                    <td> <?php echo e($user->email); ?> </td>
                                    <td> <?php echo e($user->created_at->diffForHumans()); ?> </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <?php echo $__env->make('customer.dashbroad', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_script'); ?>
<script>
  // === include 'setup' then 'config' above ===
    const labels = [
    'Cash On Delivery',
    'Credit Card',

    ];
    const data = {
    labels: labels,
    datasets: [{
        label: 'Total number of payments',
        backgroundColor:[
            '#ff7979',
            '#30336b'
        ],
        borderColor: '#ecf0f1',
        data: [<?php echo e($credit_card); ?>, <?php echo e($cod); ?>],
    }]
    };

    const config = {
    type: 'doughnut',
    data,
    options: {}
    };

  var myChart = new Chart(
    document.getElementById('myChart'),
    config
  );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.starlight', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\paravel\resources\views/home.blade.php ENDPATH**/ ?>