<?php $__env->startSection('title'); ?>
    Verification Email
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
<?php if(!Auth::user()->email_verified_at): ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 m-5">
                <div class="card">
                    <div class="card-header text-white" style="background-color: #EF4836;"><?php echo e(__('Verify Your Email Address')); ?></div>

                    <div class="card-body">
                        <?php if(session('resent')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

                            </div>
                        <?php endif; ?>

                        <?php echo e(__('Before proceeding, please check your email for a verification link.')); ?>

                        <?php echo e(__('If you did not receive the email')); ?>,
                        <form class="d-inline" method="POST" action="<?php echo e(route('verification.send')); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-link p-0 m-0 align-baseline text-danger"><u><?php echo e(__('click here to request another')); ?></u></button>.
                        </form>
                        <div class="btn" style="background-color: #EF4836; margin-left:315px;">
                            <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="text-white">
                            <i class="fa fa-power-off text-white"></i>&nbsp;&nbsp;Sign Out
                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php else: ?>
    <script>window.location = "<?php echo e(route('tohoney_home')); ?>";</script>
    
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.tohoney', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\paravel\resources\views/auth/verify.blade.php ENDPATH**/ ?>