

<?php $__env->startSection('title'); ?>
    Header
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <nav class="breadcrumb sl-breadcrumb">
        <a class="breadcrumb-item" href=" <?php echo e(route('home')); ?> ">Dashbroad</a>
        <a class="breadcrumb-item" href=" <?php echo e(route('category')); ?>">Category</a>
        <a class="breadcrumb-item" href=" <?php echo e(route('product')); ?> ">Product</a>
        <a class="breadcrumb-item" href=" <?php echo e(route('contact_backend')); ?> ">Contact</a>
        <a class="breadcrumb-item" href=" <?php echo e(route('faq')); ?> ">Faq</a>
        <span class="breadcrumb-item active">Header</span>
    </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header text-white bg-secondary">
                    <div class="row">
                        <div class="col-lg-6 pt-1">Header List</div>
                        <div class="col-lg-6 text-right">
                            <?php if($headers_normal->count() != 0 ): ?>
                            <a href="<?php echo e(route('header_soft_all')); ?>" type="button" class="btn btn-danger">Delete All</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <div class="alert alert-success text-center">
                            Total Category <?php echo e($headers_normal->count()); ?>

                        </div>
                        <?php if(session('single_soft')): ?>
                            <div class="alert alert-danger text-center">
                                <?php echo e(session('single_soft')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(session('all_soft')): ?>
                            <div class="alert alert-danger text-center">
                                <?php echo e(session('all_soft')); ?>

                            </div>
                        <?php endif; ?>
                        <thead>
                            <tr>
                                <th>Serial No</th>
                                <th>Header Title</th>
                                <th>Header description</th>
                                <th>Header Image</th>
                                <th>Created at</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $headers_normal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td> <?php echo e($loop->index+1); ?> </td>
                                <td> <?php echo e(Str::title($header->header_title)); ?> </td>
                                <td><?php echo e($header->header_description); ?></td>
                                <td>
                                    <div class="image">
                                        <img src="<?php echo e(asset('uploads/header')); ?>/<?php echo e($header->header_image); ?>" alt="Not Found" class="img-fluid">
                                    </div>
                                </td>
                                <td> <?php echo e($header->created_at->format('d/m/Y h:i:s')); ?> </td>
                                <td>
                                    <div class="btn-group" role="group" aria-label="Basic example">
                                        
                                        <a href="<?php echo e(route('header_soft', $header->id)); ?>" type="button" class="btn btn-danger">Delete</a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center text-danger">No Data To Show</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header text-white bg-secondary">Add Header</div>
                <div class="card-body">
                    <form action=" <?php echo e(route('header_post')); ?> " method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                        <?php if(session('header_insert')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('header_insert')); ?>

                            </div>
                        <?php endif; ?>
                            <label for="exampleInputPassword1">Header Title</label>
                            <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Enter Header Title" name="header_title">
                            <?php $__errorArgs = ['header_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <label for="exampleInputPassword1">Header Description</label>
                            <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Enter header description" name="header_description">
                            <?php $__errorArgs = ['header_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <label for="exampleInputPassword1">Header Image</label>
                            <input class="form-control form-control-sm" type="file" name="header_image">
                            <?php $__errorArgs = ['header_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <button type="submit" class="btn btn-outline-secondary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-5">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header bg-warning">
                    <div class="row">
                        <div class="col-lg-6 pt-1 text-white">Total Soft Category List</div>
                        <div class="col-lg-6 text-right">
                            <?php if($header_trased->count() != 0 ): ?>
                                <a href="<?php echo e(route('restore_all')); ?>" type="button" class="btn btn-success">Restore All</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <div class="alert alert-success text-center">
                            Category List<?php echo e($header_trased->count()); ?>

                        </div>
                        <?php if(session('single_force')): ?>
                            <div class="alert alert-danger text-center">
                                <?php echo e(session('single_force')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(session('single_restore')): ?>
                            <div class="alert alert-success text-center">
                                <?php echo e(session('single_restore')); ?>

                            </div>
                        <?php endif; ?>
                        <thead>
                            <tr>
                                <th>Serial No</th>
                                <th>Header Title</th>
                                <th>Header description</th>
                                <th>Header Image</th>
                                <th>Created at</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $header_trased; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td> <?php echo e($loop->index+1); ?> </td>
                                <td> <?php echo e(Str::title($header->header_title)); ?> </td>
                                <td><?php echo e($header->header_description); ?></td>
                                <td>
                                    <div class="image">
                                        <img src="<?php echo e(asset('uploads/header')); ?>/<?php echo e($header->header_image); ?>" alt="Not Found" class="img-fluid">
                                    </div>
                                </td>
                                <td> <?php echo e($header->created_at->format('d/m/Y h:i:s')); ?> </td>
                                <td>
                                    <div class="btn-group" role="group" aria-label="Basic example">
                                        <a href="<?php echo e(route('header_restore', $header->id)); ?>" type="button" class="btn btn-success text-white">Restore</a>
                                        <a href="<?php echo e(route('header_force', $header->id)); ?>" type="button" class="btn btn-danger">Delete</a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center text-danger">No Data To Show</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.starlight', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\paravel\resources\views/header/index.blade.php ENDPATH**/ ?>