

<?php $__env->startSection('title'); ?>
    Edit <?php echo e($subcategor_info->category_id); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('subcategory'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <nav class="breadcrumb sl-breadcrumb">
        <a class="breadcrumb-item" href=" <?php echo e(route('category')); ?> ">Sub Category</a>
        <span class="breadcrumb-item active"><?php echo e($subcategor_info->subcategory_name); ?></span>
    </nav>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-6 m-auto">
                <div class="card">
                    <div class="card-header text-white bg-secondary">Edit Sub Categroy</div>
                    <div class="card-body">
                        <form action=" <?php echo e(route('subcategory_post_edit', $subcategor_info->id)); ?> " method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>Category Name</label>
                                <select class="form-control" name="category_id">
                                    <option>-Choose One-</option>
                                    <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>" <?php echo e(($subcategor_info->category_id == $category->id)? 'selected': ''); ?>> 
                                            <?php echo e($category->category_name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"> <?php echo e($message); ?> </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword2">Sub Category Name</label>
                                <input type="text" class="form-control" id="exampleInputPassword2" placeholder="Enter Categroy Name" name="subcategory_name" value="<?php echo e($subcategor_info->subcategory_name); ?>">
                                <?php $__errorArgs = ['subcategory_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"> <?php echo e($message); ?> </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword3" class="d-block">Sub Category Current Image</label>
                                <img src="<?php echo e(asset('uploads/sub_category')); ?>/<?php echo e($subcategor_info->subcategory_image); ?>" alt="not found" width="150px">
                            </div>
                            <div class="form-group">
                                <label>Sub Category Image</label>
                                <input class="form-control form-control-sm" type="file" name="subcategory_image">
                                <?php $__errorArgs = ['subcategory_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"> <?php echo e($message); ?> </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <button type="submit" class="btn btn-outline-secondary">Update Category</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.starlight', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\paravel\resources\views/subcategory/edit.blade.php ENDPATH**/ ?>