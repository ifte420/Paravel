
<?php $__env->startSection('title', 'Dashbroad'); ?>
<?php $__env->startSection('body'); ?>
    <div class="container">
        <h4 class="text-success text-center">Hello Shohan <?php echo e($shohan); ?> </h4>
        <?php for($i = 1; $i <= 10; $i++): ?>
            <?php echo e($i); ?>

        <?php endfor; ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\paravel\resources\views/dashbroad.blade.php ENDPATH**/ ?>